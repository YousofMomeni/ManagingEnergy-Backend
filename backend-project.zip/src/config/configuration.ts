import { Injectable } from '@nestjs/common';
import * as fs from 'fs';
import * as path from 'path';

@Injectable()
export class ConfigLoader {
  private readonly config: Record<string, any>;

  constructor() {
    // Look for config.json in the project root directory (fajr_fullstack/),
    // which is three levels up from the current directory (fajr_fullstack/backend/src/config).
    const configPath = path.resolve(__dirname, '..', '..', '..', 'config.json');
    try {
      const configFile = fs.readFileSync(configPath, 'utf8');
      this.config = JSON.parse(configFile);
    } catch (error) {
      console.error(
        `Error loading configuration from ${configPath}. Please ensure config.json exists.`,
        error
      );
      // In case of an error, provide an empty config to prevent downstream crashes.
      this.config = {};
    }
  }

  // A method to get a specific key from the loaded configuration.
  get(key: string): any {
    return this.config[key];
  }

  // The default export function required by NestJS's ConfigModule.
  static load(): Record<string, any> {
    const loader = new ConfigLoader();
    return loader.config;
  }
}

export default ConfigLoader.load;

